CREATE DATABASE sunderland_cruise;
USE sunderland_cruise;
#Table 1
CREATE TABLE excursion_leader_information(excursion_leader_id VARCHAR(100) NOT NULL PRIMARY KEY,
excursion_leader VARCHAR(100) NOT NULL);
SELECT*FROM excursion_leader_information;

#Table 2
CREATE TABLE excursion_information(excursion_number VARCHAR(100)  NOT NULL PRIMARY KEY,
excursion VARCHAR(300),price_per_excursion INT,excursion_leader_id VARCHAR(100), port VARCHAR(100),
FOREIGN KEY(excursion_leader_id) REFERENCES excursion_leader_information(excursion_leader_id));
SELECT*FROM excursion_information;

#Table 3
CREATE TABLE passenger_information (passenger_id VARCHAR(100)  NOT NULL PRIMARY KEY,
passenger_name VARCHAR(100) NOT NULL);
SELECT*FROM passenger_information;

#Table 4
CREATE TABLE cruise_information (cruise_number INT  NOT NULL PRIMARY KEY,
cruise_name VARCHAR(200) NOT NULL);
SELECT*FROM cruise_information;

#Table 5
CREATE TABLE customer_order(order_id VARCHAR(100) NOT NULL PRIMARY KEY,
passenger_id VARCHAR(100), cruise_number INT,
FOREIGN KEY(cruise_number) REFERENCES cruise_information(cruise_number),
FOREIGN KEY(passenger_id) REFERENCES passenger_information(passenger_id));
SELECT*FROM customer_order;

#Table 6
CREATE TABLE price_information(order_id VARCHAR(100) NOT NULL, excursion_number VARCHAR(100) NOT NULL,
quantity INT,
#Composite primary key
PRIMARY KEY(order_id,excursion_number),
FOREIGN KEY (order_id) REFERENCES customer_order(order_id),
FOREIGN KEY (excursion_number)REFERENCES excursion_information(excursion_number));
SELECT*FROM price_information;

#Table 7
CREATE TABLE cabin_information(order_id VARCHAR(100), cruise_number INT,
cabin INT,PRIMARY KEY(order_id,cruise_number),
FOREIGN KEY (order_id) REFERENCES customer_order(order_id),
FOREIGN KEY (cruise_number) REFERENCES cruise_information(cruise_number));
SELECT*FROM cabin_information;

#(Claude,2026)
#Inputting data into table 1:
INSERT INTO excursion_leader_information (excursion_leader_id, excursion_leader) VALUES
('EL001', 'Sarah Thompson'),
('EL002', 'Michael Reed'),
('EL003', 'Emma Wilson'),
('EL004', 'David Hughes'),
('EL005', 'Laura Bennett'),
('EL006', 'Daniel Foster'),
('EL007', 'Sophie Turner'),
('EL008', 'James Mitchell'),
('EL009', 'Hannah Clarke'),
('EL010', 'Robert Evans'),
('EL011', 'Grace Murphy'),
('EL012', 'Thomas Wright'),
('EL013', 'Charlotte Hall'),
('EL014', 'William Scott'),
('EL015', 'Amelia Green'),
('EL016', 'Oliver Baker'),
('EL017', 'Isabella Ward'),
('EL018', 'Henry Cooper'),
('EL019', 'Lily Morgan'),
('EL020', 'George Bell'),
('EL021', 'Chloe Hughes'),
('EL022', 'Jack Phillips'),
('EL023', 'Mia Robinson'),
('EL024', 'Samuel Carter'),
('EL025', 'Ella Richardson'),
('EL026', 'Benjamin Adams'),
('EL027', 'Freya Watson'),
('EL028', 'Lucas Bennett'),
('EL029', 'Poppy Harris'),
('EL030', 'Alexander Gray'),
('EL031', 'Evelyn Price'),
('EL032', 'Harrison Cole'),
('EL033', 'Matilda Shaw'),
('EL034', 'Theodore Webb'),
('EL035', 'Penelope Hunt'),
('EL036', 'Sebastian Lloyd'),
('EL037', 'Imogen Knight'),
('EL038', 'Nathaniel Burns'),
('EL039', 'Beatrice Hart'),
('EL040', 'Maxwell Stone'),
('EL041', 'Clara Newman'),
('EL042', 'Felix Barker'),
('EL043', 'Rosalind Day'),
('EL044', 'Edward Marsh'),
('EL045', 'Vivienne Wells'),
('EL046', 'Julian Frost'),
('EL047', 'Arabella Quinn'),
('EL048', 'Dominic Reeve'),
('EL049', 'Cecilia Mason'),
('EL050', 'Reuben Sharp');
SELECT*FROM excursion_leader_information;

#Inputting data into table 2:
INSERT INTO excursion_information (excursion_number, excursion, price_per_excursion, excursion_leader_id, port) VALUES
('EX001', 'Sunderland City Heritage Walk', 25, 'EL001', 'Sunderland'),
('EX002', 'Roker Beach Coastal Tour', 30, 'EL002', 'Sunderland'),
('EX003', 'Northern Lights Photography Trip', 75, 'EL003', 'Tromso'),
('EX004', 'Whale Watching Boat Trip', 90, 'EL004', 'Reykjavik'),
('EX005', 'Historic Castle Guided Tour', 45, 'EL005', 'Edinburgh'),
('EX006', 'Local Wine Tasting Experience', 55, 'EL006', 'Bordeaux'),
('EX007', 'Mountain Hiking Adventure', 60, 'EL007', 'Bergen'),
('EX008', 'Snorkelling Reef Excursion', 80, 'EL008', 'Palma'),
('EX009', 'Fjord Kayaking Tour', 70, 'EL009', 'Geiranger'),
('EX010', 'City Cycling Tour', 35, 'EL010', 'Copenhagen'),
('EX011', 'Glacier Hike Expedition', 110, 'EL011', 'St Petersburg'),
('EX012', 'Traditional Cooking Class', 50, 'EL012', 'Naples'),
('EX013', 'Old Town Food Tour', 48, 'EL013', 'Lisbon'),
('EX014', 'Sea Cave Exploration', 65, 'EL014', 'Valletta'),
('EX015', 'Dolphin Spotting Cruise', 85, 'EL015', 'Funchal'),
('EX016', 'Vineyard and Cheese Tour', 58, 'EL016', 'Porto'),
('EX017', 'Volcano Sightseeing Trip', 120, 'EL017', 'Catania'),
('EX018', 'National Park Safari', 95, 'EL018', 'Cadiz'),
('EX019', 'Museum and Gallery Pass', 28, 'EL019', 'Amsterdam'),
('EX020', 'Hot Springs Relaxation Day', 68, 'EL020', 'Reykjavik'),
('EX021', 'Lighthouse and Cliffs Walk', 32, 'EL021', 'Cork'),
('EX022', 'Brewery and Distillery Tour', 52, 'EL022', 'Dublin'),
('EX023', 'Rainforest Canopy Walk', 88, 'EL023', 'Funchal'),
('EX024', 'Island Hopping Boat Trip', 78, 'EL024', 'Mykonos'),
('EX025', 'Sunset Sailing Cruise', 62, 'EL025', 'Santorini'),
('EX026', 'Local Market Discovery Tour', 22, 'EL026', 'Barcelona'),
('EX027', 'Ancient Ruins Expedition', 72, 'EL027', 'Athens'),
('EX028', 'Scenic Railway Journey', 66, 'EL028', 'Bergen'),
('EX029', 'Waterfall Trekking Tour', 57, 'EL029', 'Akureyri'),
('EX030', 'Polar Wildlife Excursion', 130, 'EL030', 'Longyearbyen'),
('EX031', 'Coastal Horse Riding', 54, 'EL031', 'Galway'),
('EX032', 'Hidden Waterfalls Jeep Tour', 76, 'EL032', 'Madeira'),
('EX033', 'Old Quarter Ghost Walk', 26, 'EL033', 'St Petersburg'),
('EX034', 'Pottery and Crafts Workshop', 40, 'EL034', 'Stockholm'),
('EX035', 'Tropical Garden Visit', 33, 'EL035', 'Las Palmas'),
('EX036', 'Deep Sea Fishing Trip', 92, 'EL036', 'Vigo'),
('EX037', 'Cathedral and Cloisters Tour', 38, 'EL037', 'Seville'),
('EX038', 'Highland Whisky Tasting', 64, 'EL038', 'Invergordon'),
('EX039', 'Stand-Up Paddleboarding', 47, 'EL039', 'Nice'),
('EX040', 'Mountain Cable Car Ride', 44, 'EL040', 'Gibraltar'),
('EX041', 'Olive Grove and Farm Tour', 49, 'EL041', 'Kotor'),
('EX042', 'Northern Fjord Boat Safari', 98, 'EL042', 'Oslo'),
('EX043', 'Street Art Walking Tour', 24, 'EL043', 'Hamburg'),
('EX044', 'Coral Reef Diving', 105, 'EL044', 'Tenerife'),
('EX045', 'Medieval Village Day Trip', 56, 'EL045', 'Dubrovnik'),
('EX046', 'Vintage Tram City Tour', 36, 'EL046', 'Lisbon'),
('EX047', 'Birdwatching Wetlands Tour', 42, 'EL047', 'Oslo'),
('EX048', 'Chocolate Tasting Experience', 39, 'EL048', 'Bruges'),
('EX049', 'Sunrise Hot Air Balloon', 145, 'EL049', 'Palma'),
('EX050', 'Glow Worm Cave Tour', 69, 'EL050', 'Waterford');
SELECT*FROM excursion_information;

#Inputting data into table 3:
INSERT INTO passenger_information (passenger_id, passenger_name) VALUES
('P001', 'James Carter'),
('P002', 'Olivia Bennett'),
('P003', 'William Hughes'),
('P004', 'Sophia Turner'),
('P005', 'Harry Robinson'),
('P006', 'Emily Walker'),
('P007', 'Charlie Wright'),
('P008', 'Amelia Cooper'),
('P009', 'Jacob Morgan'),
('P010', 'Isla Phillips'),
('P011', 'Thomas Edwards'),
('P012', 'Priya Kaur'),
('P013', 'Oscar Bell'),
('P014', 'Freya Hall'),
('P015', 'Leo Richardson'),
('P016', 'Ruby Watson'),
('P017', 'Archie Gray'),
('P018', 'Florence Adams'),
('P019', 'Noah Harris'),
('P020', 'Evie Murphy'),
('P021', 'Alfie Scott'),
('P022', 'Daisy Cooper'),
('P023', 'Logan Reed'),
('P024', 'Maya Foster'),
('P025', 'Preston Hayes'),
('P026', 'Layla Evans'),
('P027', 'Mason Ward'),
('P028', 'Rosie Baker'),
('P029', 'Joshua Green'),
('P030', 'Lucy Carter'),
('P031', 'Henry Dawson'),
('P032', 'Mila Fletcher'),
('P033', 'Theo Brooks'),
('P034', 'Ivy Sutton'),
('P035', 'Finley Webb'),
('P036', 'Willow Chapman'),
('P037', 'Reggie Palmer'),
('P038', 'Prudence Clarke'),
('P039', 'Albie Barnes'),
('P040', 'Aria Lawson'),
('P041', 'Frankie Doyle'),
('P042', 'Esme Norton'),
('P043', 'Teddy Vaughan'),
('P044', 'Bonnie Hart'),
('P045', 'Rory Sullivan'),
('P046', 'Sienna Marsh'),
('P047', 'Hugo Bradley'),
('P048', 'Nina Coleman'),
('P049', 'Stanley Pope'),
('P050', 'Eliza Frost');
SELECT*FROM passenger_information;

#Inputting data into table 4:
INSERT INTO cruise_information (cruise_number, cruise_name) VALUES
(1, 'Northern Lights Voyage'),
(2, 'Baltic Sea Explorer'),
(3, 'Norwegian Fjords Adventure'),
(4, 'Mediterranean Sunset Cruise'),
(5, 'Iceland and Greenland Expedition'),
(6, 'British Isles Discovery'),
(7, 'Atlantic Coastal Journey'),
(8, 'Arctic Circle Expedition'),
(9, 'Scottish Highlands Cruise'),
(10, 'Canary Islands Escape'),
(11, 'Caribbean Paradise Voyage'),
(12, 'Greek Islands Odyssey'),
(13, 'Spanish Riviera Cruise'),
(14, 'Portugal and Madeira Tour'),
(15, 'Faroe Islands Explorer'),
(16, 'Celtic Sea Adventure'),
(17, 'North Sea Heritage Cruise'),
(18, 'Scandinavian Capitals Tour'),
(19, 'Irish Coastline Voyage'),
(20, 'Channel Islands Getaway'),
(21, 'Azores Atlantic Cruise'),
(22, 'White Cliffs Coastal Tour'),
(23, 'Hebrides Island Cruise'),
(24, 'Shetland and Orkney Voyage'),
(25, 'Bay of Biscay Crossing'),
(26, 'French Riviera Escape'),
(27, 'Italian Coast Discovery'),
(28, 'Adriatic Sea Cruise'),
(29, 'Aegean Explorer'),
(30, 'Polar Wilderness Expedition'),
(31, 'Madeira Island Retreat'),
(32, 'Norwegian Coastal Express'),
(33, 'Western Mediterranean Gems'),
(34, 'Eastern Caribbean Sun'),
(35, 'Lofoten Islands Voyage'),
(36, 'Cornish Coast Cruise'),
(37, 'Dalmatian Coast Discovery'),
(38, 'Black Sea Explorer'),
(39, 'Balearic Islands Escape'),
(40, 'Greenland Ice Expedition'),
(41, 'Amalfi Coast Cruise'),
(42, 'Scilly Isles Adventure'),
(43, 'Swedish Archipelago Tour'),
(44, 'Icelandic Saga Voyage'),
(45, 'Costa Brava Cruise'),
(46, 'Sicilian Sun Voyage'),
(47, 'Danish Capitals Cruise'),
(48, 'Bay of Naples Discovery'),
(49, 'Outer Hebrides Expedition'),
(50, 'Antarctic Frontier Voyage');
SELECT*FROM cruise_information;

#Inputting data into table 5:
INSERT INTO customer_order (order_id, passenger_id, cruise_number) VALUES
('ORD001', 'P001', 1),
('ORD002', 'P002', 2),
('ORD003', 'P003', 3),
('ORD004', 'P004', 4),
('ORD005', 'P005', 5),
('ORD006', 'P006', 6),
('ORD007', 'P007', 7),
('ORD008', 'P008', 8),
('ORD009', 'P009', 9),
('ORD010', 'P010', 10),
('ORD011', 'P011', 11),
('ORD012', 'P012', 12),
('ORD013', 'P013', 13),
('ORD014', 'P014', 14),
('ORD015', 'P015', 15),
('ORD016', 'P016', 16),
('ORD017', 'P017', 17),
('ORD018', 'P018', 18),
('ORD019', 'P019', 19),
('ORD020', 'P020', 20),
('ORD021', 'P021', 21),
('ORD022', 'P022', 22),
('ORD023', 'P023', 23),
('ORD024', 'P024', 24),
('ORD025', 'P025', 25),
('ORD026', 'P026', 26),
('ORD027', 'P027', 27),
('ORD028', 'P028', 28),
('ORD029', 'P029', 29),
('ORD030', 'P030', 30),
('ORD031', 'P031', 31),
('ORD032', 'P032', 32),
('ORD033', 'P033', 33),
('ORD034', 'P034', 34),
('ORD035', 'P035', 35),
('ORD036', 'P036', 36),
('ORD037', 'P037', 37),
('ORD038', 'P038', 38),
('ORD039', 'P039', 39),
('ORD040', 'P040', 40),
('ORD041', 'P041', 41),
('ORD042', 'P042', 42),
('ORD043', 'P043', 43),
('ORD044', 'P044', 44),
('ORD045', 'P045', 45),
('ORD046', 'P046', 46),
('ORD047', 'P047', 47),
('ORD048', 'P048', 48),
('ORD049', 'P049', 49),
('ORD050', 'P050', 50);
SELECT*FROM customer_order;

#Inputting data into table 6:
INSERT INTO price_information (order_id, excursion_number, quantity) VALUES
('ORD001', 'EX001', 6),
('ORD002', 'EX002', 1),
('ORD003', 'EX003', 3),
('ORD004', 'EX004', 2),
('ORD005', 'EX005', 4),
('ORD006', 'EX006', 1),
('ORD007', 'EX007', 2),
('ORD008', 'EX008', 3),
('ORD009', 'EX009', 1),
('ORD010', 'EX010', 2),
('ORD011', 'EX011', 1),
('ORD012', 'EX012', 2),
('ORD013', 'EX013', 3),
('ORD014', 'EX014', 1),
('ORD015', 'EX015', 2),
('ORD016', 'EX016', 4),
('ORD017', 'EX017', 1),
('ORD018', 'EX018', 2),
('ORD019', 'EX019', 3),
('ORD020', 'EX020', 1),
('ORD021', 'EX021', 2),
('ORD022', 'EX022', 1),
('ORD023', 'EX023', 2),
('ORD024', 'EX024', 3),
('ORD025', 'EX025', 1),
('ORD026', 'EX026', 2),
('ORD027', 'EX027', 4),
('ORD028', 'EX028', 1),
('ORD029', 'EX029', 2),
('ORD030', 'EX030', 1),
('ORD031', 'EX031', 3),
('ORD032', 'EX032', 2),
('ORD033', 'EX033', 1),
('ORD034', 'EX034', 2),
('ORD035', 'EX035', 4),
('ORD036', 'EX036', 1),
('ORD037', 'EX037', 2),
('ORD038', 'EX038', 3),
('ORD039', 'EX039', 1),
('ORD040', 'EX040', 2),
('ORD041', 'EX041', 1),
('ORD042', 'EX042', 2),
('ORD043', 'EX043', 3),
('ORD044', 'EX044', 1),
('ORD045', 'EX045', 2),
('ORD046', 'EX046', 4),
('ORD047', 'EX047', 1),
('ORD048', 'EX048', 2),
('ORD049', 'EX049', 1),
('ORD050', 'EX050', 3);
SELECT*FROM price_information;

#Inputting data into table 7:
INSERT INTO cabin_information (order_id, cruise_number, cabin) VALUES
('ORD001', 1, 101),
('ORD002', 2, 102),
('ORD003', 3, 103),
('ORD004', 4, 104),
('ORD005', 5, 105),
('ORD006', 6, 106),
('ORD007', 7, 107),
('ORD008', 8, 108),
('ORD009', 9, 109),
('ORD010', 10, 110),
('ORD011', 11, 111),
('ORD012', 12, 112),
('ORD013', 13, 113),
('ORD014', 14, 114),
('ORD015', 15, 115),
('ORD016', 16, 116),
('ORD017', 17, 117),
('ORD018', 18, 118),
('ORD019', 19, 119),
('ORD020', 20, 120),
('ORD021', 21, 121),
('ORD022', 22, 122),
('ORD023', 23, 123),
('ORD024', 24, 124),
('ORD025', 25, 125),
('ORD026', 26, 126),
('ORD027', 27, 127),
('ORD028', 28, 128),
('ORD029', 29, 129),
('ORD030', 30, 130),
('ORD031', 31, 131),
('ORD032', 32, 132),
('ORD033', 33, 133),
('ORD034', 34, 134),
('ORD035', 35, 135),
('ORD036', 36, 136),
('ORD037', 37, 137),
('ORD038', 38, 138),
('ORD039', 39, 139),
('ORD040', 40, 140),
('ORD041', 41, 141),
('ORD042', 42, 142),
('ORD043', 43, 143),
('ORD044', 44, 144),
('ORD045', 45, 145),
('ORD046', 46, 146),
('ORD047', 47, 147),
('ORD048', 48, 148),
('ORD049', 49, 149),
('ORD050', 50, 150);
SELECT*FROM cabin_information;

#MY T-NUMBER IS P509342 SO IT INCREASES BY 93 PERCENT. THUS 1+(93/100)=1.93
UPDATE excursion_information
SET price_per_excursion=price_per_excursion*(1.93)
WHERE port ='Copenhagen';
SELECT price_per_excursion, port FROM excursion_information WHERE port='Copenhagen';

#Q2:
SELECT customer_order.order_id AS "Order ID", customer_order.passenger_id AS "Passenger ID",
    passenger_information.passenger_name AS "Name of passenger", cabin_information.cabin AS "Cabin"
FROM customer_order
INNER JOIN passenger_information ON customer_order.passenger_id = passenger_information.passenger_id
INNER JOIN cabin_information  ON customer_order.order_id = cabin_information.order_id;


#Q3:
SELECT DISTINCT passenger_information.passenger_id AS "Passenger ID",
       passenger_information.passenger_name AS "Name of passenger",
       excursion_information.port AS "Port",
       excursion_information.excursion AS "Excursion"
FROM passenger_information
INNER JOIN customer_order ON passenger_information.passenger_id = customer_order.passenger_id
INNER JOIN price_information ON customer_order.order_id = price_information.order_id
INNER JOIN excursion_information ON price_information.excursion_number = excursion_information.excursion_number
WHERE excursion_information.port IN ('St Petersburg', 'Oslo');

#Q4:
SELECT customer_order.order_id AS "Order Number",
       passenger_information.passenger_name AS "Passenger Name",
       price_information.quantity AS "Tickets Bought"
FROM price_information
INNER JOIN customer_order ON price_information.order_id = customer_order.order_id
INNER JOIN passenger_information ON customer_order.passenger_id = passenger_information.passenger_id
WHERE price_information.excursion_number = 'EX001'
  AND price_information.quantity > 4;



#Q5:
SELECT excursion_information.excursion_number AS "Excursion Number",
       excursion_information.excursion AS "Excursion Name",
       SUM(price_information.quantity) AS "Total Booked"
FROM excursion_information
INNER JOIN price_information ON excursion_information.excursion_number = price_information.excursion_number
GROUP BY excursion_information.excursion_number, excursion_information.excursion
ORDER BY "Total Booked" DESC;


#6:
SELECT passenger_information.passenger_id AS "Passenger ID",
       passenger_information.passenger_name AS "Passenger Name",
       excursion_information.excursion_number AS "Excursion Number",
       excursion_information.excursion AS "Excursion Name",
       excursion_information.price_per_excursion AS "Price",
       excursion_information.port AS "Port"
FROM passenger_information
INNER JOIN customer_order ON passenger_information.passenger_id = customer_order.passenger_id
INNER JOIN price_information ON customer_order.order_id = price_information.order_id
INNER JOIN excursion_information ON price_information.excursion_number = excursion_information.excursion_number
WHERE passenger_information.passenger_name LIKE 'Pr%' AND passenger_information.passenger_name NOT LIKE '%se%';

